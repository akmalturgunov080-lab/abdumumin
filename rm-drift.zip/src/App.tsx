/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Game from './components/Game';

export default function App() {
  return (
    <div className="w-full h-screen bg-black">
      <Game />
    </div>
  );
}
